//
//  Lista.swift
//  Tienda
//
//  Created by Usuario invitado on 5/10/18.
//  Copyright © 2018 1. All rights reserved.
//

import Foundation

var listaProduc = [productos]()

