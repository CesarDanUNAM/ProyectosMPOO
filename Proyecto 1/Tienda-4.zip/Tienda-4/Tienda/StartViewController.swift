//
//  StartViewController.swift
//  Tienda
//
//  Created by Usuario invitado on 5/10/18.
//  Copyright © 2018 1. All rights reserved.
//

import UIKit

class StartViewController: UIViewController {
    @IBOutlet weak var Boton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    view.backgroundColor = UIColor.blue
        
    }

    

}
