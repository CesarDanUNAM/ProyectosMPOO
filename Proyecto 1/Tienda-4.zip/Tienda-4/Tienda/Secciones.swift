//
//  Secciones.swift
//  Tienda
//
//  Created by Usuario invitado on 2/10/18.
//  Copyright © 2018 1. All rights reserved.
//

import Foundation

struct productos {
    var nombre : String
    var precio : Double
    var imagen : String
}


