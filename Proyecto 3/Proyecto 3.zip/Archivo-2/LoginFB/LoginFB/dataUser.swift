//
//  dataUser.swift
//  LoginFB
//
//  Created by macbook on 11/22/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import Foundation


struct firebaseData {
    var nombre : String
    var correo : String
    var userUID : String
    var password : String
}
