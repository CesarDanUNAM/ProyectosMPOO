//
//  UserCell.swift
//  LoginFB
//
//  Created by macbook on 11/22/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class UserCell: UITableViewCell{
    
    @IBOutlet weak var name: UILabel!
    
  
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configureCell(user: firebaseData){
        name.text = user.nombre
       
    }
    
}
