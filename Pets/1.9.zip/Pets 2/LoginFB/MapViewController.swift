//
//  MapViewController.swift
//  LoginFB
//
//  Created by Macbook on 11/16/18.
//  Copyright © 2018 . All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class MapViewController: UIViewController,MKMapViewDelegate,CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    let location = CLLocation()
    let geocoder = CLGeocoder()
    var adress = ""


    @IBOutlet weak var mapa: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        locationManager.startUpdatingLocation()
        
        self.mapa.delegate = self

        mapa.delegate = self
        mapa.showsScale = true
        mapa.showsPointsOfInterest = true
        mapa.showsUserLocation = true
        
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
        
        //var location = CLLocationCoordinate2DMake(19.688830578, -98.8396099749)
        //var location = CLLocationCoordinate2D(latitude: 19.688830578, longitude: -98.8396099749)
        //var span = MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
        //var region = MKCoordinateRegion(center: location, span: span)
        //mapa.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        //annotation.coordinate = destCoordinate
        annotation.title = "HOLa?"
        annotation.subtitle = "HO?"
        mapa.addAnnotation(annotation)
        let tapGesture = UILongPressGestureRecognizer(target: self, action: #selector(action(gestureRecognizer:)))
        mapa.addGestureRecognizer(tapGesture)

    }
    

    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region = MKCoordinateRegion(center: mapa.userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.009, longitudeDelta: 0.009))
        
        mapa.setRegion(region, animated: true)
    }
    
    @IBAction func showAddAddressView() {
        
        let alertVC = UIAlertController(title: "Add Address", message: nil, preferredStyle: .alert)
        alertVC.addTextField { textField in
            
        }
        
        let okAction = UIAlertAction(title: "Ok", style: .default) { action in
            if let textField = alertVC.textFields?.first {
                
                self.reverseGeocode(adress: textField.text!)
                self.showOnMap()
                
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { action in
            
        }
        
        alertVC.addAction(okAction)
        alertVC.addAction(cancelAction)
        
        self.present(alertVC, animated: true, completion: nil)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations)
    }
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.darkGray
        renderer.lineWidth = 2.0
        return renderer
    }
    func reverseGeocode(adress : String ){
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(adress){ (placemarks,error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            guard let placemarks = placemarks, let placemark = placemarks.first
                else{
                    return
            }
            self.addPlacemarkToMap(placemark : placemark)
            
        }
    }
    func showOnMap(){
        let sourceCoodinate = locationManager.location?.coordinate
        
        let destCoordinate = CLLocationCoordinate2DMake(19.33091 , -99.184034)
        
        let sourcePlacemark = MKPlacemark(coordinate: sourceCoodinate!)
        let destPlacemark = MKPlacemark(coordinate: destCoordinate)
        
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destItem = MKMapItem(placemark: destPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceItem
        directionRequest.destination = destItem
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate(completionHandler: {
            response, error in
            guard let respone = response else{
                if let error = error{
                    print("Erore???")
                }
                return
            }
            let route = respone.routes[0]
            self.mapa.addOverlay(route.polyline, level: .aboveRoads)
            
            let rekt = route.polyline.boundingMapRect
            self.mapa.setRegion(MKCoordinateRegion.init(rekt), animated: true)
        })
        
    }
    func addPlacemarkToMap(placemark : CLPlacemark){
        let coordinate = placemark.location?.coordinate
        let annotation  = MKPointAnnotation()
        annotation.coordinate = coordinate!
        self.mapa.addAnnotation(annotation)
        //self.mapa.add(MKCircle(center: annotation.coordinate, radius: 200 ))
        
    }
    @objc func action(gestureRecognizer: UIGestureRecognizer) {
        
        self.mapa.removeAnnotations(mapa.annotations)
        
        let touchPoint = gestureRecognizer.location(in: mapa)
        let newCoords = mapa.convert(touchPoint, toCoordinateFrom: mapa)
        
        geocoderLocation(newLocation: CLLocation(latitude: newCoords.latitude, longitude: newCoords.longitude))
        
        let latitud = String(format: "%.6f", newCoords.latitude)
        let longitud = String(format: "%.6f", newCoords.longitude)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = newCoords
        annotation.title = adress
        annotation.subtitle = "Latitud: \(latitud) Longitud: \(longitud)"
        mapa.addAnnotation(annotation)
    }
    
    func geocoderLocation(newLocation: CLLocation) {
        var dir  = ""
        geocoder.reverseGeocodeLocation(newLocation) { (placemarks, error) in
            if error == nil {
                dir = "No se ha podido determinar la dirección"
            }
            if let placemark = placemarks?.last {
                dir = self.stringFromPlacemark(placemark: placemark)
            }
            self.adress = dir
        }
        print("************+")
        print(adress)
        
    }
    func stringFromPlacemark(placemark: CLPlacemark) -> String {
        var line = ""
        
        if let p = placemark.thoroughfare {
            line += p + ", "
        }
        if let p = placemark.subThoroughfare {
            line += p + " "
            print(line)
        }
        if let p = placemark.locality {
            line += " (" + p + ")"

        }
        if let p = placemark.postalCode{
            line += " (" + p + ")"
        }
        return line
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        
        let annotationID = "AnnotationID"
        
        var annotationView : MKAnnotationView?
        
        if let dequeuedAnnotationView = mapView.dequeueReusableAnnotationView(withIdentifier: annotationID) {
            annotationView = dequeuedAnnotationView
            annotationView?.annotation = annotation
        } else {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: annotationID)
        }
        
        if let annotationView = annotationView {
            annotationView.canShowCallout = true
            annotationView.image = UIImage(named: "img_pin")
        }
        return annotationView
    }

}
