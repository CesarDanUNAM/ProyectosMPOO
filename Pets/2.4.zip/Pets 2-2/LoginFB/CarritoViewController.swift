//
//  CarritoViewController.swift
//  LoginFB
//
//  Created by MacBook on 12/5/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class CarritoViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    @IBOutlet weak var Table: UITableView!
    
    @IBOutlet weak var TotalC: UILabel!
    
    var Total: Double = 0
    var limpia: Bool = false
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return listaProduct.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda2", for: indexPath)
        
        
        cell.textLabel?.text = "\(listaProduct[indexPath.row].nombre)- \(listaProduct[indexPath.row].precio)"
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Eliminar") { (action, sourceview, completionHandler) in
            
            listaProduct.remove(at: indexPath.row)
            
            self.limpia = true 
            self.Table.deleteRows(at: [indexPath], with: .fade )
            completionHandler(true)
            self.CuentaTotal()
        }
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction])
        
        
        return swipeConfiguration
        
        
    }
    
    func CuentaTotal (){
        Total = 0
        for i in listaProduct{
            Total = i.precio + Total
            
        }
        TotalC.text = "Total = \(Total)"
    }
        
        
    


    override func viewDidLoad() {
        super.viewDidLoad()
        CuentaTotal()
        // Do any additional setup after loading the view.
    }
    

   
    
    
}
