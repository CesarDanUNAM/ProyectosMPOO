//
//  Veterinaria.swift
//  LoginFB
//
//  Created by macbook  on 12/5/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import Foundation

struct vete {
    //var nombre: String
    var latitude: Double
    var longitude: Double
}
