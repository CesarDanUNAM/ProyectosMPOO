//
//  listaProduct.swift
//  LoginFB
//
//  Created by MacBook on 12/5/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import Foundation
    var listaProduct = [Productos]()
