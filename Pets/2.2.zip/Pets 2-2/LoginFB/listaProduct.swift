//
//  listaProduct.swift
//  LoginFB
//
//  Created by MacBook on 12/5/18.
//  Copyright © 2018. All rights reserved.
//

import Foundation
var listaProduct = [String] ()
var listaImagen = [String] ()
var listaPrecio = [Double]()
