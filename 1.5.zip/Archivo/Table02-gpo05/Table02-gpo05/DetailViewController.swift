//
//  DetailViewController.swift
//  Table02-gpo05
//
//  Created by Germán Santos Jaimes on 3/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var imagenDetail: UIImageView!
    @IBOutlet weak var etiqueta: UILabel!
    var producto: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        etiqueta.text = producto
        imagenDetail.image = UIImage(named: producto)
        
    }

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
