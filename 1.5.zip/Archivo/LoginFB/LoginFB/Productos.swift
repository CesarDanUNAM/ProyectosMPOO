//
//  Productos.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/13/18.
//  Copyright © 2018 . All rights reserved.
//

import Foundation

struct Productos {
    var nombre: String
    var precio: Double
    var imagen: String
    //var desc: String
}
